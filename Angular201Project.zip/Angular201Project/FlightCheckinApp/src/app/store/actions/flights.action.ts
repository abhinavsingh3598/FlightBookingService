import { Action } from '@ngrx/store';
import { FlightModel } from 'src/app/models/flight-model';
import * as types from '../../models/flights.action.types';

export class LoadFlightDataAction implements Action {
  readonly type = types.LOAD_FLIGHTS_DATA;
}
export class LoadFlightSuccessAction implements Action {
  readonly type = types.LOAD_FLIGHTS_DATA_SUCCESS;

  constructor(public payload: FlightModel[]) { }
}

export type Actions = LoadFlightDataAction | LoadFlightSuccessAction;
