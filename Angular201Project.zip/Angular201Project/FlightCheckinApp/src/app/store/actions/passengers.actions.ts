import { Action } from '@ngrx/store';
import * as types from '../../models/passengers.action.type';
import { PassengerModel } from 'src/app/models/passenger-model';


// fetch data
export class LoadPassengerDataAction implements Action {
  readonly type = types.LOAD_PASSENGERS_DATA;
}
export class LoadPassengerSuccessAction implements Action {
  readonly type = types.LOAD_PASSENGERS_DATA_SUCCESS;
  constructor(public payload: PassengerModel[]) { }
}
// edit
export class EditPassengerSeatAction implements Action {
  readonly type = types.EDIT_PASSENGERS_SEAT;
  constructor(public payload: PassengerModel) { }
}
export class EditPassengerSuccessSeatAction implements Action {
  readonly type = types.EDIT_PASSENGER_SEAT_SUCESS;
  constructor(public payload: PassengerModel) { }
}

// CREATE PASSENGER
export class CreatePassenger implements Action {
  readonly type = types.CREATE_PASSENGERS;

  constructor(public payload: PassengerModel) { }
}
export class CreatePassengerSuccess implements Action {
  readonly type = types.CREATE_PASSENGERS_SUCCESS;

  constructor(public payload: PassengerModel) { }
}
export class CreatePassengerFail implements Action {
  readonly type = types.CREATE_PASSENGERS_FAIL;

  constructor(public payload: string) { }
}

// UPDATE PASSENEGR
export class UpdatePassenger implements Action {
  readonly type = types.UPDATE_PASSENGERS;

  constructor(public payload: PassengerModel) { }
}

export class UpdatePassengerSuccess implements Action {
  readonly type = types.UPDATE_PASSENGERS_SUCCESS;

  constructor(public payload: PassengerModel) { }
}
export class UpdatePassengerFail implements Action {
  readonly type = types.UPDATE_PASSENGERS_FAIL;

  constructor(public payload: string) { }
}


export type Actions = LoadPassengerDataAction |
  LoadPassengerSuccessAction | EditPassengerSeatAction | EditPassengerSuccessSeatAction |
  CreatePassenger
  | CreatePassengerSuccess
  | CreatePassengerFail
  | UpdatePassenger
  | UpdatePassengerSuccess
  | UpdatePassengerFail;

