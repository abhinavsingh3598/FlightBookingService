import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map, mergeMap } from 'rxjs/operators';
import { FlightService } from 'src/app/services/flight.service';
import * as types from '../../models/passengers.action.type';
import * as passengerActions from '../actions/passengers.actions';


@Injectable({
  providedIn: 'root',
})
export class PassengersEffects {
  constructor(
    private flightService: FlightService,
    private actions$: Actions,
  ) { }

  @Effect() loadPassengers$: Observable<Action> = this.actions$.pipe(
    ofType<passengerActions.LoadPassengerDataAction>(
      types.LOAD_PASSENGERS_DATA,
    ),
    mergeMap(() =>
      this.flightService
        .getAllpassengers()
        .pipe(
          map(
            (passengers) =>
              new passengerActions.LoadPassengerSuccessAction(passengers),
          ),
        ),
    ),
  );

  // Upadte passenger data
  @Effect()
  updateCustomer$ = this.actions$.pipe(
    ofType<passengerActions.UpdatePassenger>(types.UPDATE_PASSENGERS),
    mergeMap(action => this.flightService.updatePassenger(action.payload).pipe(
      map(passenger => new passengerActions.UpdatePassengerSuccess(passenger))
    ))
  );
}


  // //Add Passenger data
  // @Effect() createPassenger$: Observable<Action> = this.actions$.pipe(
  //   ofType<passengerActions.CreatePassenger>(
  //     types.CREATE_PASSENGERS
  //   ),
  //   mergeMap((action) =>
  //     this.flightService
  //       .addPassenger(action.payload)
  //       .pipe(
  //         map(
  //           (newPassengers) =>
  //             new passengerActions.CreatePassengerSuccess(newPassengers)
  //         ),

  //       )
  //   )
  // );


