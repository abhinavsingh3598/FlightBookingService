import { Injectable } from '@angular/core';
import { Actions, Effect, ofType } from '@ngrx/effects';
import { Action } from '@ngrx/store';
import { Observable } from 'rxjs';
import { map, mergeMap } from 'rxjs/operators';
import { FlightService } from 'src/app/services/flight.service';
import * as types from '../../models/flights.action.types';
import * as flightActions from '../actions/flights.action';

@Injectable(
    {
        providedIn: 'root',
    })

export class FlightsEffects {
    constructor(
        private flightService: FlightService,
        private actions$: Actions
    ) {
    }
    @Effect() loadFlights$: Observable<Action> = this.actions$.pipe(
        ofType<flightActions.LoadFlightDataAction>(types.LOAD_FLIGHTS_DATA),
        mergeMap(() =>
            this.flightService
                .getAllFlights()
                .pipe(
                    map((flights) => new flightActions.LoadFlightSuccessAction(flights))

                )
        )
    );
}
