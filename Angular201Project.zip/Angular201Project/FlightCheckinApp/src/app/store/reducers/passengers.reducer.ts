import { createEntityAdapter, EntityAdapter } from '@ngrx/entity';
import { PassengerModel } from 'src/app/models/passenger-model';

import { PassengerState } from '../../models/app.state';
import * as types from '../../models/passengers.action.type';
import * as passengerActions from '../actions/passengers.actions';

export const initialState: PassengerState = {
  passengers: [],
};
export const passengeradapter: EntityAdapter<PassengerModel> = createEntityAdapter<PassengerModel>();

export function PassengerReducer(
  state = initialState,
  action: passengerActions.Actions,
): PassengerState {
  switch (action.type) {
    case types.LOAD_PASSENGERS_DATA_SUCCESS: {
      return {
        ...state,
        passengers: action.payload,
      };
    }

    case types.EDIT_PASSENGER_SEAT_SUCESS: {
      return {
        ...state,
        passengers: state.passengers.map((pId) => {
          if (pId.passengerId === action.payload.passengerId) {
            console.log('payLoad:===>' + action.payload.passengerSeatNumber);
            return action.payload;
          } else {
            return pId;
          }
        }),
      };
    }

    // CREATE PASSENGER
    case types.CREATE_PASSENGERS_SUCCESS: {

      return { ...state, passengers: state.passengers.concat(action.payload) };
    }

    // update
    case types.UPDATE_PASSENGERS_SUCCESS:
      return {
        ...state, passengers: state.passengers.map(passenger => {
          if (passenger.passengerId === action.payload.passengerId) {
            console.log('Upadetd Passenger payload ===>' + action.payload);
            return action.payload;
          }
          else {
            return passenger;
          }
        }
        )
      };

    default:
      return state;
  }
}
