import {ActionReducerMap} from '@ngrx/store';
import { AppState, PassengerState } from '../../models/app.state';
import { FlightReducer } from './flights.reducer';
import { PassengerReducer } from './passengers.reducer';


export interface State {
  flightState: AppState;
  passengerState: PassengerState;
}

export const reducers: ActionReducerMap<State> = {
  flightState: FlightReducer,
  passengerState: PassengerReducer,
};
