import * as flightActions from '../actions/flights.action';
import * as types from '../../models/flights.action.types';
import { AppState } from '../../models/app.state';


export const initialState: AppState = {
  flights: [],
};
export function FlightReducer(
  state = initialState,
  action: flightActions.Actions
):
  AppState {

  switch (action.type) {
    case types.LOAD_FLIGHTS_DATA:
      return { ...state };

    case types.LOAD_FLIGHTS_DATA_SUCCESS: {
      return { ...state, flights: action.payload };
    }
    default:
      return state;
  }
}
