import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, Subject, Subscription } from 'rxjs';
import { AdminModel } from '../models/admin-model';
import { FlightModel } from '../models/flight-model';
import { PassengerModel } from '../models/passenger-model';

@Injectable({
  providedIn: 'root'
})
export class FlightService {

  onCancelClicked = new Subject<boolean>();
  passengerUrl = 'http://localhost:3000/passenger-model';
  flightUrl = 'http://localhost:3000/flight-model';
  seatUrl = 'http://localhost:3000/seat-model';
  adminUrl = 'http://localhost:3000/admin-model';


  admin: AdminModel;
  constructor(private http: HttpClient) { }

  addAdmin(adminModel: AdminModel): Subscription {
    return this.http.post(this.adminUrl, adminModel).subscribe(data => {
      console.log(data);
    });
  }

  addPassenger(passenger: PassengerModel): Subscription {
    return this.http.post(this.passengerUrl, passenger).subscribe(data => {
      console.log(data);
    });
  }

  onDailogCancel(): void {
    this.onCancelClicked.next(true);
  }

  setadminObjectForLocalStorage(admin: AdminModel): void {
    this.admin = admin;
  }

  getadminObjectForLocalStorage(): AdminModel {
    return this.admin;
  }

  getFlightById(id: number): Observable<FlightModel> {
    return this.http.get<FlightModel>(this.flightUrl + '/?flightId=' + id);
  }

  getPassengerById(pid: number): Observable<PassengerModel> {
    return this.http.get<PassengerModel>(this.passengerUrl + '/?passengerId=' + pid);
  }

  getAllPassengersByFlightId(id: number): Observable<PassengerModel[]> {
    return this.http.get<PassengerModel[]>(this.passengerUrl + '/?passengerFlightId=' + id);
  }

  getAllFlights(): Observable<FlightModel[]> {
    return this.http.get<FlightModel[]>(this.flightUrl);
  }

  getAllpassengers(): Observable<PassengerModel[]> {
    return this.http.get<PassengerModel[]>(this.passengerUrl);
  }

  getAllAdmins(): Observable<AdminModel[]> {
    return this.http.get<AdminModel[]>(this.adminUrl);
  }

  updateFlight(flight: FlightModel): Observable<any> {
    return this.http.put<any>(this.flightUrl + '/' + flight.flightId, flight
    );
  }


  updatePassenger(passenger: PassengerModel): Observable<PassengerModel> {
    return this.http.put<any>(
      this.passengerUrl + '/' + passenger.passengerId, passenger
    );
  }
}


