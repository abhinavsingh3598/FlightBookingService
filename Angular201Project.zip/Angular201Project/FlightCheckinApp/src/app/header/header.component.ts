import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { GoogleLoginProvider, SocialAuthService, SocialUser } from 'angularx-social-login';
import { AdminDailogComponent } from '../adminModule/admin-dailog/admin-dailog.component';
import { FlightService } from '../services/flight.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.sass']
})
export class HeaderComponent implements OnInit {

  @Output() movedIn = new EventEmitter<boolean>();

  user: SocialUser;
  staffLoggedIn: boolean;
  adminLoggedIn: boolean;
  slides = [{ image: 'assets/images/firstCarouselImg.jpg' },
  { image: 'assets/images/secondCarouselImg.jpg' },
  { image: 'assets/images/thirdCarouselImg.jpg' },
  { image: 'assets/images/fourthCarouselImg.jpg' }
  ];

  constructor(private router: Router, private route: ActivatedRoute, private dialog: MatDialog, private authService: SocialAuthService,
              private flightService: FlightService

  ) { }

  ngOnInit(): void {

    this.authService.authState.subscribe((user) => {
      this.user = user;
    });

    if (localStorage.getItem('staff') != null && localStorage.getItem('admin') == null) {
      this.staffLoggedIn = true;
      this.adminLoggedIn = false;
    }
    if (localStorage.getItem('admin') != null && localStorage.getItem('staff') == null) {
      this.staffLoggedIn = false;
      this.adminLoggedIn = true;
    }

    if (localStorage.getItem('staff') == null && localStorage.getItem('admin') == null) {
      this.staffLoggedIn = false;
      this.adminLoggedIn = false;
    }

  }

  staffLogin(): void {
    this.movedIn.emit(true);
    this.authService.signIn(GoogleLoginProvider.PROVIDER_ID).then((data) => {

      if (localStorage.getItem('admin') != null) {
        localStorage.removeItem('admin');
      }

      localStorage.setItem('staff', JSON.stringify(data));

      if (localStorage.getItem('staff') != null) {
        this.staffLoggedIn = true;
        this.adminLoggedIn = false;
        this.router.navigate(['/staffDashboard'], { relativeTo: this.route });
      }
    });
  }

  adminSignUp(): void {
    this.movedIn.emit(true);
    const dialogRef = this.dialog.open(AdminDailogComponent, {
      height: '420px',
      width: '600px',
      data: 'adminSignUp',
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
      this.movedIn.emit(false);
    });

  }


  adminLogin(): void {
    this.movedIn.emit(true);
    const dialogRef = this.dialog.open(AdminDailogComponent, {
      height: '350px',
      width: '600px',
      data: 'adminLogin',
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(result => {

      this.movedIn.emit(true);

      if (localStorage.getItem('staff') != null) {
        localStorage.removeItem('staff');
      }


      if (localStorage.getItem('admin') != null) {
        this.adminLoggedIn = true;
        this.staffLoggedIn = false;
      }
    });
  }


  signOut(): void {

    if (localStorage.getItem('admin') != null) {
      localStorage.removeItem('admin');
    }
    if (localStorage.getItem('staff') != null) {
      localStorage.removeItem('staff');
    }

    this.authService.signOut();
    this.adminLoggedIn = false;
    this.staffLoggedIn = false;
    this.router.navigate([''], { relativeTo: this.route });
  }

}
