import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/Forms';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { GoogleLoginProvider, SocialAuthServiceConfig, SocialLoginModule } from 'angularx-social-login';
import { AdminModule } from './adminModule/admin.module';
import { StaffModule } from './staffModule/staff.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AppMaterial } from './app.material';
import { AuthGuard } from './auth.guard';
import { HeaderComponent } from './header/header.component';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { StoreModule } from '@ngrx/store';
import { FlightReducer} from './store/reducers/flights.reducer';
import {PassengerReducer} from './store/reducers/passengers.reducer';
import { FlightsEffects} from './store/effects/flights.effects';
import { PassengersEffects} from './store/effects/passengers.effects';
import { EffectsModule } from '@ngrx/effects';
import { StoreRouterConnectingModule } from '@ngrx/router-store';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    AppMaterial,
    StoreModule.forRoot({}),
    StoreModule.forFeature('flights', FlightReducer),
    StoreModule.forFeature('passengers', PassengerReducer),
    EffectsModule.forRoot([FlightsEffects, PassengersEffects]),
    StoreRouterConnectingModule.forRoot(),
    HttpClientModule,
    SocialLoginModule,
    AdminModule,
    StaffModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production })
  ],
  providers: [
    {
      provide: 'SocialAuthServiceConfig',
      useValue: {
        autoLogin: true,
        providers: [
          {
            id: GoogleLoginProvider.PROVIDER_ID,
            provider: new GoogleLoginProvider(
              '342306562616-okvqq1otnk7dl5jpaqf35rf62j60gkaf.apps.googleusercontent.com',
            ),
          },
        ],
      } as SocialAuthServiceConfig,
    }, AuthGuard
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
