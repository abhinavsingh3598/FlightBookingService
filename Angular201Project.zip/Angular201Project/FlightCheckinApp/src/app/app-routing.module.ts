import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  
  {
    path: 'admin', loadChildren: () => import('./adminModule/admin.module').then(m => m.AdminModule)
  },
  {
    path: 'staff', loadChildren: () => import('./staffModule/staff.module').then(m => m.StaffModule)
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
