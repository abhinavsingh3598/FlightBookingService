import { FlightModel } from './flight-model';
import { PassengerModel } from './passenger-model';


export interface AppState {
  readonly flights: FlightModel[];
}

export interface PassengerState {
  readonly passengers: PassengerModel[];
}
