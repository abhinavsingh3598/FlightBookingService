import { SeatModel } from './seat-model';

export class FlightModel {
    flightId: number;
    flightName: string;
    flightArrivalCity: string;
    flightDestinationCity: string;
    flightTotalTimeDuration: string;
    flightCost: string;
    flightDepTime: string;
    flightAncillaries: string[];
    flightMeals: string[];
    flightShoppingItems: string[];
    flightSeats: SeatModel[];
    flightSpecialMeals: boolean;

}
