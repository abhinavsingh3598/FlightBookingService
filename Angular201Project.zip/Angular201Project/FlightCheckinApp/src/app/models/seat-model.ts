import { PassengerModel } from './passenger-model';

export class SeatModel {

    seatId: number;
    seatStatus: boolean;
    seatPassenger: PassengerModel[];

}
