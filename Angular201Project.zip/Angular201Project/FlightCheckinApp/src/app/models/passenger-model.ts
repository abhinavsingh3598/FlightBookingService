import { SeatModel } from './seat-model';

export class PassengerModel {
    passengerId: number;
    passengerName: string;
    passengerDOB: string;
    passengerPassportNum: string;
    passengerAddress: string;
    passengerSeatNumber: number;
    passengerAnicallaries: string[];
    passengerMeals: string[];
    passengerShopping: string[];
    passengerWithInfacts: boolean;
    passengerWithWheelChair: boolean;
    passengerCheckedIn: boolean;
    passengerSpecialMealsTaken: boolean;
    passengerFlightId: number;

}
