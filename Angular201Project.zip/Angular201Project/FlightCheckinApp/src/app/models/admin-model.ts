export class AdminModel {
    adminEmail: string;
    adminUserName: string;
    adminPassword: string;

}
