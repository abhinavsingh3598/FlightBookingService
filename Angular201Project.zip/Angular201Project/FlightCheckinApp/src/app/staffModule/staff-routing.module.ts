import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../auth.guard';
import { DisplaySeatMapPassengersComponent } from './check-in/display-seat-map-passengers/display-seat-map-passengers.component';
import { SelectCurrentFlightsComponent } from './check-in/select-current-flights/select-current-flights.component';
import { SelectModifySeatsComponent } from './check-in/select-modify-seats/select-modify-seats.component';
import { DisplayFlightsComponent } from './in-flight/display-flights/display-flights.component';
import { DisplayPassengersAncillariesComponent } from './in-flight/display-passengers-ancillaries/display-passengers-ancillaries.component';
import { ManagePassengersAncillariesComponent } from './in-flight/manage-passengers-ancillaries/manage-passengers-ancillaries.component';
import { StaffDashboardComponent } from './staff-dashboard/staff-dashboard.component';

const routes: Routes = [

    {
        path: 'staffDashboard', component: StaffDashboardComponent, canActivate: [AuthGuard], data: { role: 'staff' }
    },
    {
        path: 'check-in', component: SelectCurrentFlightsComponent, canActivate: [AuthGuard], data: { role: 'staff' }
    },
    {
        path: 'in-flight', component: DisplayFlightsComponent, canActivate: [AuthGuard], data: { role: 'staff' }
    },
    {
        path: 'displayCheckInDetails/:flightId', component: DisplaySeatMapPassengersComponent
        , canActivate: [AuthGuard], data: { role: 'staff' }
    },
    {
        path: 'displayPassengerAncillaries/:flightId', component: DisplayPassengersAncillariesComponent,
        canActivate: [AuthGuard], data: { role: 'staff' }
    },
    {
        path: 'ancillaryService/:passengerId/:ancillary', component: ManagePassengersAncillariesComponent,
        canActivate: [AuthGuard], data: { role: 'staff' }
    },
    {
        path: 'mealService/:passengerId/:meal', component: ManagePassengersAncillariesComponent,
        canActivate: [AuthGuard], data: { role: 'staff' }
    },
    {
        path: 'shopService/:passengerId/:shop', component: ManagePassengersAncillariesComponent,
        canActivate: [AuthGuard], data: { role: 'staff' }
    },
    {
        path: 'changePassengerSeat/:passengerId/:changeSeat', component: SelectModifySeatsComponent, canActivate: [AuthGuard], data: { role: 'staff' }
    },
    {
        path: 'passengerCheckIn/:passengerId/:checkIn', component: SelectModifySeatsComponent,
        canActivate: [AuthGuard], data: { role: 'staff' }
    }


];


@NgModule({
    declarations: [],
    imports: [CommonModule, RouterModule.forChild(routes)],
    exports: [RouterModule],
    providers: [],
})

export class StaffRoutingModule {
}
