import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute } from '@angular/router';
import { FlightModel } from 'src/app/models/flight-model';
import { PassengerModel } from 'src/app/models/passenger-model';
import { FlightService } from 'src/app/services/flight.service';
import jsPDF from 'jspdf';

@Component({
  selector: 'app-select-modify-seats',
  templateUrl: './select-modify-seats.component.html',
  styleUrls: ['./select-modify-seats.component.sass']
})
export class SelectModifySeatsComponent implements OnInit {

  passenger: PassengerModel;
  flight: FlightModel;
  checkIn: boolean;
  changeSeat: boolean;
  selectedSeat: any;
  ticketSuccess: boolean;
  constructor(private flightService: FlightService, private route: ActivatedRoute, private snackBar: MatSnackBar) { }

  ngOnInit(): void {

    this.route.params.subscribe(param => {

      this.checkIn = param.checkIn != null;
      this.changeSeat = param.changeSeat != null;

      this.flightService.getPassengerById(+param.passengerId).subscribe(data => {
        this.passenger = data[0];
        this.flightService.getFlightById(this.passenger.passengerFlightId).subscribe(flight => {

          this.flight = flight[0];

        });
      });


    }

    );
  }

  onSubmit(event: any): void {
    this.selectedSeat = event.srcElement.id;
    console.log(this.selectedSeat);
  }

  passengerClick(): void {

    if (this.checkIn) {

      for (const seat of this.flight.flightSeats) {
        if (seat.seatId === this.passenger.passengerSeatNumber) {
          seat.seatPassenger = [];
          seat.seatStatus = true;
          break;
        }
      }

      // tslint:disable-next-line: radix
      this.passenger.passengerSeatNumber = parseInt(this.selectedSeat);
      this.passenger.passengerCheckedIn = true;

      for (const seat of this.flight.flightSeats) {

        // tslint:disable-next-line: radix
        if (seat.seatId === parseInt(this.selectedSeat)) {
          seat.seatPassenger.push(this.passenger);
          seat.seatStatus = false;
          break;
        }
      }
      this.flightService.updatePassenger(this.passenger).subscribe(passData => {
        console.log(passData);
      });

      this.flightService.updateFlight(this.flight).subscribe(flightData => {
        this.snackBar.open('Checked In', 'Successfully !!!', {
          duration: 2000,

        });
        this.ticketSuccess = true;
      });

    }

    if (this.changeSeat) {


      for (const seat of this.flight.flightSeats) {
        if (seat.seatId === this.passenger.passengerSeatNumber) {
          seat.seatPassenger = [];
          seat.seatStatus = true;
          break;
        }
      }

      for (const seat of this.flight.flightSeats) {
        // tslint:disable-next-line: radix
        if (seat.seatId === parseInt(this.selectedSeat)) {
          seat.seatPassenger.push(this.passenger);
          seat.seatStatus = false;
          break;
        }
      }
      // tslint:disable-next-line: radix
      this.passenger.passengerSeatNumber = parseInt(this.selectedSeat);

      this.flightService.updatePassenger(this.passenger).subscribe(passData => {
        console.log(passData);
      });

      this.flightService.updateFlight(this.flight).subscribe(flightData => {

        this.snackBar.open('Seat Changed', 'Successfully !!!', {
          duration: 2000,
        });
        this.ticketSuccess = true;
      });

    }
  }


  dwnldPDF(): void {

    const doc = new jsPDF('p', 'mm', [230, 250]);
    doc.text(' Welcome Digital AirWays ', 70, 13);
    doc.text(' ____________________', 70, 14);
    doc.text(' ____________________', 70, 15);
    doc.text('Congraluation Your Ticket has been Booked !!!', 50, 30);
    doc.text('Passenger Details =>', 10, 50);
    doc.text('Passenger ID: ' + this.passenger.passengerId, 10, 65);
    doc.text('Passenger Name: Mr. ' + this.passenger.passengerName.toUpperCase(), 10, 75);
    doc.text('Passenger Seat Number: ' + this.passenger.passengerSeatNumber, 10, 85);
    doc.text('Passnger Flight Name: ' + this.flight.flightName, 10, 95);
    doc.text('Passenger Ancillaries Opted List: ', 10, 105);
    let count = 10;
    if (this.passenger.passengerAnicallaries.length === 0) {
      doc.text(' NA ', 10, 115);
    }
    else {
      this.passenger.passengerAnicallaries.forEach(element => {
        doc.text('* ' + element, count, 115);
        count = count + 40;
      });
    }
    doc.text('Passenger Meals Opted List: ', 10, 125);
    if (this.passenger.passengerMeals.length === 0) {
      doc.text(' NA ', 10, 135);
    }
    else {
      this.passenger.passengerMeals.forEach(element => {
        doc.text('* ' + element, 10, 135);
      });
    }
    if (this.flight.flightSpecialMeals) {
      doc.text('Special Meals Taken : Yes', 10, 145);
    }
    else {
      doc.text('Special Meals Taken : NO', 10, 145);
    }

    doc.text('Flight Duration: ' + this.flight.flightTotalTimeDuration, 10, 155);
    doc.text('Passenger Arrival City: ' + this.flight.flightArrivalCity.toUpperCase(), 10, 165);
    doc.text('Passenger Destination City: ' + this.flight.flightDestinationCity.toUpperCase(), 10, 175);
    doc.text('Passenger Total Cost Including Taxes: Rs.' + this.flight.flightCost, 10, 185);
    const niceimage = new Image();
    niceimage.src = '/assets/images/flightBackgroundImg.jpg';
    doc.addImage(niceimage, 'JPEG', 150, 65, 60, 100);
    doc.text('****************************** Thanks For Booking Ticket ******************************', 10, 220);
    // doc.output('dataurlnewwindow');
    doc.save(this.passenger.passengerId + '.pdf');

  }

}


