import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectModifySeatsComponent } from './select-modify-seats.component';

describe('SelectModifySeatsComponent', () => {
  let component: SelectModifySeatsComponent;
  let fixture: ComponentFixture<SelectModifySeatsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectModifySeatsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectModifySeatsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
