import { Component, OnInit } from '@angular/core';
import { FlightModel } from 'src/app/models/flight-model';
import { FlightService } from 'src/app/services/flight.service';

@Component({
  selector: 'app-select-current-flights',
  templateUrl: './select-current-flights.component.html',
  styleUrls: ['./select-current-flights.component.sass']
})
export class SelectCurrentFlightsComponent implements OnInit {

  constructor(private flightService: FlightService) { }

  flights: FlightModel[];
  filter = { ZeroToSix: false, SixToTwelve: false, TwelveToEighteen: false, EighteenToTwentyfour: false };
  filteredFlights: FlightModel[] = [];

  displayedColumns: string[] = ['flightId', 'flightName', 'flightArrivalCity', 'flightDestinationCity', 'flightTotalTimeDuration',
    'flightCost', 'getAllPassengers'];


  ngOnInit(): void {
    this.flightService.getAllFlights().subscribe(data => {
      this.flights = data;
      this.filteredFlights = this.flights;
    });

  }


  filterChange(): void {

    // when all boxes are unchecked
    if (this.filter.ZeroToSix === false && this.filter.SixToTwelve === false && this.filter.EighteenToTwentyfour === false
      && this.filter.TwelveToEighteen === false) {

      this.filteredFlights = this.flights;
    } else {

      // for 0 to 6
      if (this.filter.ZeroToSix === true && this.filter.SixToTwelve === false && this.filter.EighteenToTwentyfour === false
        && this.filter.TwelveToEighteen === false) {
        this.filteredFlights = this.flights.filter(x =>
          // tslint:disable-next-line: radix
          parseInt(x.flightDepTime.substring(0, 2)) < 6);
      }
      // for 6 to 12
      if (this.filter.ZeroToSix === false && this.filter.SixToTwelve === true && this.filter.EighteenToTwentyfour === false
        && this.filter.TwelveToEighteen === false) {
        this.filteredFlights = this.flights.filter(x =>
          // tslint:disable-next-line: radix
          parseInt(x.flightDepTime.substring(0, 2)) >= 6 && parseInt(x.flightDepTime.substring(0, 2)) < 12);
      }

      // for 12 to 18
      if (this.filter.ZeroToSix === false && this.filter.SixToTwelve === false && this.filter.EighteenToTwentyfour === false
        && this.filter.TwelveToEighteen === true) {
        this.filteredFlights = this.flights.filter(x =>
          // tslint:disable-next-line: radix
          parseInt(x.flightDepTime.substring(0, 2)) >= 12 && parseInt(x.flightDepTime.substring(0, 2)) < 18);
      }

      // for 18 to 24
      if (this.filter.ZeroToSix === false && this.filter.SixToTwelve === false && this.filter.EighteenToTwentyfour === true
        && this.filter.TwelveToEighteen === false) {
        this.filteredFlights = this.flights.filter(x =>
          // tslint:disable-next-line: radix
          parseInt(x.flightDepTime.substring(0, 2)) >= 18 && parseInt(x.flightDepTime.substring(0, 2)) < 24);
      }

      // for 0 to 6 and 6 to 12
      if (this.filter.ZeroToSix === true && this.filter.SixToTwelve === true && this.filter.EighteenToTwentyfour === false
        && this.filter.TwelveToEighteen === false) {
        this.filteredFlights = this.flights.filter(x =>
          // tslint:disable-next-line: radix
          parseInt(x.flightDepTime.substring(0, 2)) < 12);
      }

      // for 0 to 6 and 12 to 18
      if (this.filter.ZeroToSix === true && this.filter.SixToTwelve === false && this.filter.TwelveToEighteen === true
        && this.filter.EighteenToTwentyfour === false) {
        this.filteredFlights = this.flights.filter(x =>
          // tslint:disable-next-line: radix
          parseInt(x.flightDepTime.substring(0, 2)) < 6 || (parseInt(x.flightDepTime.substring(0, 2)) >= 12
          // tslint:disable-next-line: radix
          && parseInt(x.flightDepTime.substring(0, 2)) < 18));
      }
      // for 0 to 6 and 18 to 24
      if (this.filter.ZeroToSix === true && this.filter.SixToTwelve === false && this.filter.EighteenToTwentyfour === true
        && this.filter.TwelveToEighteen === false) {
        this.filteredFlights = this.flights.filter(x =>
          // tslint:disable-next-line: radix
          parseInt(x.flightDepTime.substring(0, 2)) < 6 || (parseInt(x.flightDepTime.substring(0, 2)) >= 18
          // tslint:disable-next-line: radix
          && parseInt(x.flightDepTime.substring(0, 2)) < 24));
      }

      // for 6 to 12 and 12 to 18
      if (this.filter.ZeroToSix === false && this.filter.SixToTwelve === true && this.filter.TwelveToEighteen === true
        && this.filter.EighteenToTwentyfour === false) {
        this.filteredFlights = this.flights.filter(x =>
          // tslint:disable-next-line: radix
          parseInt(x.flightDepTime.substring(0, 2)) >= 6 && parseInt(x.flightDepTime.substring(0, 2)) < 18);
      }

      // for 6 to 12 and 18 to 24
      if (this.filter.ZeroToSix === false && this.filter.SixToTwelve === true && this.filter.TwelveToEighteen === false
        && this.filter.EighteenToTwentyfour === true) {
        this.filteredFlights = this.flights.filter(x =>
          // tslint:disable-next-line: radix
          parseInt(x.flightDepTime.substring(0, 2)) >= 6 && parseInt(x.flightDepTime.substring(0, 2)) < 12
          // tslint:disable-next-line: radix
          || (parseInt(x.flightDepTime.substring(0, 2)) >= 18 && parseInt(x.flightDepTime.substring(0, 2)) < 24));
      }

      // for  12 to 18 and 18 to 24
      if (this.filter.ZeroToSix === false && this.filter.SixToTwelve === false && this.filter.TwelveToEighteen === true
        && this.filter.EighteenToTwentyfour === true) {
        this.filteredFlights = this.flights.filter(x =>
          // tslint:disable-next-line: radix
          parseInt(x.flightDepTime.substring(0, 2)) >= 12 && parseInt(x.flightDepTime.substring(0, 2)) < 24);
      }

      // for 0 to 6 , 6 to 12 , 12 to 18
      if (this.filter.ZeroToSix === true && this.filter.SixToTwelve === true && this.filter.TwelveToEighteen === true
        && this.filter.EighteenToTwentyfour === false) {
        this.filteredFlights = this.flights.filter(x =>
          // tslint:disable-next-line: radix
          parseInt(x.flightDepTime.substring(0, 2)) >= 0 && parseInt(x.flightDepTime.substring(0, 2)) < 18);
      }

      // for for 0 to 6 , 6 to 12 , 18 to 24
      if (this.filter.ZeroToSix === true && this.filter.SixToTwelve === true && this.filter.TwelveToEighteen === false
        && this.filter.EighteenToTwentyfour === true) {
        this.filteredFlights = this.flights.filter(x =>
          // tslint:disable-next-line: radix
          parseInt(x.flightDepTime.substring(0, 2)) >= 0 && parseInt(x.flightDepTime.substring(0, 2)) < 12
          // tslint:disable-next-line: radix
          || (parseInt(x.flightDepTime.substring(0, 2)) >= 18 && parseInt(x.flightDepTime.substring(0, 2)) < 24));
      }

      // for 6 to 12 , 12 to 18 , 18 to 24
      if (this.filter.ZeroToSix === false && this.filter.SixToTwelve === true && this.filter.TwelveToEighteen === true
        && this.filter.EighteenToTwentyfour === true) {
        this.filteredFlights = this.flights.filter(x =>
          // tslint:disable-next-line: radix
          parseInt(x.flightDepTime.substring(0, 2)) >= 6 && parseInt(x.flightDepTime.substring(0, 2)) < 24);
      }

      // for 0 to 6 , 12 to 18 , 18 to 24
      if (this.filter.ZeroToSix === true && this.filter.SixToTwelve === false && this.filter.TwelveToEighteen === true
        && this.filter.EighteenToTwentyfour === true) {
        this.filteredFlights = this.flights.filter(x =>
          // tslint:disable-next-line: radix
          parseInt(x.flightDepTime.substring(0, 2)) < 6 || (parseInt(x.flightDepTime.substring(0, 2)) >= 12
          // tslint:disable-next-line: radix
          && parseInt(x.flightDepTime.substring(0, 2)) < 24));
      }

      // for all checked
      if (this.filter.ZeroToSix === true && this.filter.SixToTwelve === true && this.filter.TwelveToEighteen === true
        && this.filter.EighteenToTwentyfour === true) {
        this.filteredFlights = this.flights.filter(x =>
          // tslint:disable-next-line: radix
          parseInt(x.flightDepTime.substring(0, 2)) < 24);
      }


    }
  }

}
