import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectCurrentFlightsComponent } from './select-current-flights.component';

describe('SelectCurrentFlightsComponent', () => {
  let component: SelectCurrentFlightsComponent;
  let fixture: ComponentFixture<SelectCurrentFlightsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectCurrentFlightsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectCurrentFlightsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
