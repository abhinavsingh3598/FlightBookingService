import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { FlightModel } from 'src/app/models/flight-model';
import { PassengerModel } from 'src/app/models/passenger-model';
import { FlightService } from 'src/app/services/flight.service';

@Component({
  selector: 'app-display-seat-map-passengers',
  templateUrl: './display-seat-map-passengers.component.html',
  styleUrls: ['./display-seat-map-passengers.component.sass']
})
export class DisplaySeatMapPassengersComponent implements OnInit {

  flightId: number;
  // list of passengers in the present flights
  passengers: PassengerModel[];
  filteredPassengers: PassengerModel[] = [];
  flight: FlightModel;


  displayedColumns: string[] = ['passengerId', 'passengerName', 'passengerAncillaries', 'passengerSeats', 'changeSeat',
    'checkInStatus'];

  filter = { checkin: false, infant: false, wheelchair: false, Notcheckin: false };

  constructor(private flightService: FlightService, private route: ActivatedRoute) {

  }

  ngOnInit(): void {
    this.route.params.subscribe(
      (params: Params) => {
        this.flightId = +params.flightId;
        this.flightService.getAllPassengersByFlightId(this.flightId).subscribe(data => {
          this.passengers = data;
          this.filteredPassengers = this.passengers;
        });
        this.flightService.getFlightById(this.flightId).subscribe(data => this.flight = data[0]);
      });
  }



  checkOutPassenger(passengerId: number): void {

    for (const passenger of this.passengers) {
      if (passenger.passengerId === passengerId) {
        for (const seat of this.flight.flightSeats) {
          if (seat.seatId === passenger.passengerSeatNumber) {
            seat.seatStatus = true;
            seat.seatPassenger = [];
            console.log(this.flight);
            this.flightService.updateFlight(this.flight).subscribe(data => {
              console.log(data);
            });
            break;
          }
        }
        passenger.passengerSeatNumber = 0;
        passenger.passengerCheckedIn = false;
        console.log(passenger);
        this.flightService.updatePassenger(passenger).subscribe(data => {
          console.log(data);
        });
        break;
      }
    }
    // window.location.reload();
  }




  filterChange(): void {
    if (this.filter.checkin === false && this.filter.infant === false && this.filter.wheelchair === false
      && this.filter.Notcheckin === false) {

      this.filteredPassengers = this.passengers;
    }
    else {
      // only check in true
      if (this.filter.checkin === true && this.filter.Notcheckin === false && this.filter.infant === false
        && this.filter.wheelchair === false) {
        this.filteredPassengers = this.passengers.filter(x =>
          x.passengerCheckedIn === true);
      }
      // only non check in true
      if (this.filter.checkin === false && this.filter.Notcheckin === true && this.filter.infant === false
        && this.filter.wheelchair === false) {
        this.filteredPassengers = this.passengers.filter(x =>
          x.passengerCheckedIn === false);
      }

      // only infant
      if (this.filter.checkin === false && this.filter.Notcheckin === false && this.filter.infant === true
        && this.filter.wheelchair === false) {
        this.filteredPassengers = this.passengers.filter(x =>
          x.passengerWithInfacts === true);
      }
      // only for weel chair
      if (this.filter.checkin === false && this.filter.Notcheckin === false && this.filter.infant === false
        && this.filter.wheelchair === true) {
        this.filteredPassengers = this.passengers.filter(x =>
          x.passengerWithWheelChair === true);

      }

      // check in and infant
      if (this.filter.checkin === true && this.filter.Notcheckin === false && this.filter.infant === true
        && this.filter.wheelchair === false) {
        this.filteredPassengers = this.passengers.filter(x =>
          (x.passengerCheckedIn === true) && (x.passengerWithInfacts === true));
      }

      // check in and wheel chair
      if (this.filter.checkin === true && this.filter.Notcheckin === false && this.filter.infant === false
        && this.filter.wheelchair === true) {
        this.filteredPassengers = this.passengers.filter(x =>
          (x.passengerCheckedIn === true) && (x.passengerWithWheelChair === true));
      }
      // check in and infant  and wheel chair
      if (this.filter.checkin === true && this.filter.Notcheckin === false && this.filter.infant === true
        && this.filter.wheelchair === true) {
        this.filteredPassengers = this.passengers.filter(x =>
          (x.passengerCheckedIn === true) && (x.passengerWithWheelChair === true)
          && (x.passengerWithInfacts === true));
      }

      // not check in and infant
      if (this.filter.checkin === false && this.filter.Notcheckin === true && this.filter.infant === true
        && this.filter.wheelchair === false) {
        this.filteredPassengers = this.passengers.filter(x =>
          (x.passengerCheckedIn === false) && (x.passengerWithInfacts === true));
      }

      // not checked in and wheel chair
      if (this.filter.checkin === false && this.filter.Notcheckin === true && this.filter.infant === false
        && this.filter.wheelchair === true) {
        this.filteredPassengers = this.passengers.filter(x =>
          (x.passengerCheckedIn === false) && (x.passengerWithWheelChair === true));
      }
      // not checkd iba nd infant  and wheelchair
      if (this.filter.checkin === false && this.filter.Notcheckin === true && this.filter.infant === true
        && this.filter.wheelchair === true) {
        this.filteredPassengers = this.passengers.filter(x =>
          (x.passengerCheckedIn === false) && (x.passengerWithWheelChair === true)
          && (x.passengerWithInfacts === true));
      }

      // infant nd wheelchair
      if (this.filter.checkin === false && this.filter.Notcheckin === false
        && this.filter.infant === true && this.filter.wheelchair === true) {
        this.filteredPassengers = this.passengers.filter(x =>
          (x.passengerWithWheelChair === true) && (x.passengerWithInfacts === true));
      }


      // checked in and notcheckd in
      if (this.filter.checkin === true && this.filter.Notcheckin === true) {
        this.filteredPassengers = [];
      }

    }

  }


}
