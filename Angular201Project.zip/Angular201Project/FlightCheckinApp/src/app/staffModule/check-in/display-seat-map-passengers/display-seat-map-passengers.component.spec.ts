import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplaySeatMapPassengersComponent } from './display-seat-map-passengers.component';

describe('DisplaySeatMapPassengersComponent', () => {
  let component: DisplaySeatMapPassengersComponent;
  let fixture: ComponentFixture<DisplaySeatMapPassengersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisplaySeatMapPassengersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplaySeatMapPassengersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
