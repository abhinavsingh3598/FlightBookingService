import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FlightModel } from 'src/app/models/flight-model';
import { PassengerModel } from 'src/app/models/passenger-model';
import { FlightService } from 'src/app/services/flight.service';

@Component({
  selector: 'app-display-passengers-ancillaries',
  templateUrl: './display-passengers-ancillaries.component.html',
  styleUrls: ['./display-passengers-ancillaries.component.sass']
})
export class DisplayPassengersAncillariesComponent implements OnInit {

  constructor(private flightService: FlightService, private route: ActivatedRoute) { }

  flightId: number;
  passengersModel: PassengerModel[];
  passengerExist: boolean;
  flight: FlightModel;

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.flightService.getAllPassengersByFlightId(+params.flightId).subscribe(data => {
        this.passengersModel = data;
        this.passengerExist = data.length !== 0;
      });
      this.flightService.getFlightById(+params.flightId).subscribe(
        data => {
          this.flight = data[0];
        }
      );
    });
  }
}

