import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DisplayPassengersAncillariesComponent } from './display-passengers-ancillaries.component';

describe('DisplayPassengersAncillariesComponent', () => {
  let component: DisplayPassengersAncillariesComponent;
  let fixture: ComponentFixture<DisplayPassengersAncillariesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DisplayPassengersAncillariesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DisplayPassengersAncillariesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
