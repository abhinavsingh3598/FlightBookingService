import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params } from '@angular/router';
import { FlightModel } from 'src/app/models/flight-model';
import { PassengerModel } from 'src/app/models/passenger-model';
import { FlightService } from 'src/app/services/flight.service';

@Component({
  selector: 'app-display-flights',
  templateUrl: './display-flights.component.html',
  styleUrls: ['./display-flights.component.sass']
})
export class DisplayFlightsComponent implements OnInit {

  constructor(private flightService: FlightService, private route: ActivatedRoute) { }

  flights: FlightModel[];
  flight: FlightModel;
  passengers = [];
  flightId: number;

  displayedColumns: string[] = ['flightId', 'flightName', 'flightArrivalCity', 'flightDestinationCity', 'flightTotalTimeDuration',
    'flightCost', 'getAllPassengers'];
  ngOnInit(): void {
    this.flightService.getAllFlights().subscribe(data => {
      this.flights = data;
      console.log(data);
    });


  }

  passengerRequiresSM(flightId: number): void {

    this.flights.forEach(element => {
      if (flightId == element.flightId) {
        this.flight = element;
      }
    });

  }

}
