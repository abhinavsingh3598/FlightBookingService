import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagePassengersAncillariesComponent } from './manage-passengers-ancillaries.component';

describe('ManagePassengersAncillariesComponent', () => {
  let component: ManagePassengersAncillariesComponent;
  let fixture: ComponentFixture<ManagePassengersAncillariesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManagePassengersAncillariesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagePassengersAncillariesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
