import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Params } from '@angular/router';
import { FlightService } from 'src/app/services/flight.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { PassengerModel } from 'src/app/models/passenger-model';
import { FlightModel } from 'src/app/models/flight-model';

@Component({
  selector: 'app-manage-passengers-ancillaries',
  templateUrl: './manage-passengers-ancillaries.component.html',
  styleUrls: ['./manage-passengers-ancillaries.component.sass']
})
export class ManagePassengersAncillariesComponent implements OnInit {

  constructor(private snackBar: MatSnackBar, private route: ActivatedRoute, private flightService: FlightService) { }

  id: number;
  operationValue: string;
  flight: FlightModel;
  addBox = false;
  itemExist = false;
  passenger: PassengerModel;
  selectedAncillary: string;

  ngOnInit(): void {

    this.route.params.subscribe(
      (params: Params) => {

        this.id = +params.passengerId;

        if (params.ancillary) {
          this.operationValue = params.ancillary;
        }
        if (params.meal) {
          this.operationValue = params.meal;
        }
        if (params.shop) {
          this.operationValue = params.shop;
        }
        console.log(this.operationValue);
      }
    );


    this.flightService.getPassengerById(this.id).subscribe(passengerdata => {
      this.passenger = passengerdata[0];
      console.log(this.passenger);

      this.flightService.getFlightById(this.passenger.passengerFlightId).subscribe(flightdata => {
        this.flight = flightdata[0];
        console.log(this.flight);

      });
    });

  }

  addOperation(): void {
    this.addBox = true;

  }



  selectedItemUpdate(ancillary: string): void {
    let count = 0;
    if (this.operationValue === 'ancillary') {
      this.passenger.passengerAnicallaries.forEach(element => {
        if (element === ancillary) {
          count = 1;
        }
      });
    }
    if (this.operationValue === 'meal') {
      this.passenger.passengerMeals.forEach(element => {
        if (element === ancillary) {
          count = 1;
        }
      });
    }
    if (this.operationValue === 'shop') {
      this.passenger.passengerShopping.forEach(element => {
        if (element === ancillary) {
          count = 1;
        }
      });
    }
    if (count === 1) {
      this.itemExist = true;
    }
    else {
      this.itemExist = false;
    }
  }


  addAncillary(): void {
    console.log(this.selectedAncillary);
    if (!this.itemExist) {
      if (this.operationValue === 'ancillary') {
        this.passenger.passengerAnicallaries.push(this.selectedAncillary);
      }
      if (this.operationValue === 'meal') {
        this.passenger.passengerMeals.push(this.selectedAncillary);
      }
      if (this.operationValue === 'shop') {
        this.passenger.passengerShopping.push(this.selectedAncillary);
      }

      console.log(this.passenger);

      this.flightService.updatePassenger(this.passenger).subscribe(data => {
        this.snackBar.open(' Ancillary Successfully !!!', 'Added', {
          duration: 2000,
        });
        window.location.reload();
      });
    }
  }
}
