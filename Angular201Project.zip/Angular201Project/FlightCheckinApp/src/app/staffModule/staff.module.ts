import { FormsModule, ReactiveFormsModule } from '@angular/Forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { AppMaterial } from '../app.material';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StaffRoutingModule } from './staff-routing.module';
import { DisplaySeatMapPassengersComponent } from './check-in/display-seat-map-passengers/display-seat-map-passengers.component';
import { SelectCurrentFlightsComponent } from './check-in/select-current-flights/select-current-flights.component';
import { SelectModifySeatsComponent } from './check-in/select-modify-seats/select-modify-seats.component';
import { DisplayFlightsComponent } from './in-flight/display-flights/display-flights.component';
import { DisplayPassengersAncillariesComponent } from './in-flight/display-passengers-ancillaries/display-passengers-ancillaries.component';
import { ManagePassengersAncillariesComponent } from './in-flight/manage-passengers-ancillaries/manage-passengers-ancillaries.component';
import { StaffDashboardComponent } from './staff-dashboard/staff-dashboard.component';

@NgModule({
    declarations: [
        StaffDashboardComponent,
        DisplayFlightsComponent,
        DisplayPassengersAncillariesComponent,
        SelectCurrentFlightsComponent,
        DisplaySeatMapPassengersComponent,
        SelectModifySeatsComponent,
        ManagePassengersAncillariesComponent

    ],
    imports: [
        CommonModule,
        StaffRoutingModule,
        RouterModule,
        FormsModule,
        ReactiveFormsModule,
        AppMaterial
    ],
    exports: [],
    providers: [],
})

export class StaffModule {

}
