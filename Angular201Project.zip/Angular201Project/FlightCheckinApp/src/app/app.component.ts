import { Component, OnInit } from '@angular/core';
import { FlightService } from './services/flight.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.sass']
})
export class AppComponent implements OnInit {
  constructor() {
  }
  title = 'FlightCheckinApp';
  ngOnInit(): void {

  }

}
