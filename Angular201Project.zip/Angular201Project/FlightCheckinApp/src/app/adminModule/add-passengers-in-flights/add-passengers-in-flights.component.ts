import { Component, OnInit } from '@angular/core';
import { FlightService } from 'src/app/services/flight.service';
import { FlightModel } from 'src/app/models/flight-model';

@Component({
  selector: 'app-add-passengers-in-flights',
  templateUrl: './add-passengers-in-flights.component.html',
  styleUrls: ['./add-passengers-in-flights.component.sass']
})
export class AddPassengersInFlightsComponent implements OnInit {
  constructor(private flightService: FlightService) { }

  displayedColumns: string[] = ['flightId', 'flightName', 'flightArrivalCity', 'flightDestinationCity', 'flightTotalTimeDuration',
    'flightCost', 'addPassenger'];

  flights: FlightModel[];
  ngOnInit(): void {
    this.flightService.getAllFlights().subscribe(data => { this.flights = data; });

  }

}
