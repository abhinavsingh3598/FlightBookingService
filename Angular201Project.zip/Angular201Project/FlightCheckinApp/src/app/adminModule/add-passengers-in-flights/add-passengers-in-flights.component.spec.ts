import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddPassengersInFlightsComponent } from './add-passengers-in-flights.component';

describe('AddPassengersInFlightsComponent', () => {
  let component: AddPassengersInFlightsComponent;
  let fixture: ComponentFixture<AddPassengersInFlightsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddPassengersInFlightsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddPassengersInFlightsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
