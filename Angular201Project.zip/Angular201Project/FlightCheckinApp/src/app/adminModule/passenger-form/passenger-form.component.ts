import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Params } from '@angular/router';
import { FlightModel } from 'src/app/models/flight-model';
import { PassengerModel } from 'src/app/models/passenger-model';
import { FlightService } from 'src/app/services/flight.service';

@Component({
  selector: 'app-passenger-form',
  templateUrl: './passenger-form.component.html',
  styleUrls: ['./passenger-form.component.sass']
})
export class PassengerFormComponent implements OnInit {

  passengerAnicallaries = new FormControl('');

  passengerForm = new FormGroup({
    passengerFName: new FormControl('', Validators.required),
    passengerLName: new FormControl('', Validators.required),
    passengerPassportNum: new FormControl(''),
    passengerAddress: new FormControl(''),
    passengerDOB: new FormControl(''),
    passengerWithInfacts: new FormControl('', Validators.required),
    passengerWithWheelChair: new FormControl('', Validators.required),
    passengerSpecialMealsTaken: new FormControl('', Validators.required)

  });

  passenger: PassengerModel;
  flight: FlightModel;
  flightId: number;
  passengerId: number;
  step = -1;
  passengerIdGen: number;
  addFormValid = false;
  editMode = false;

  constructor(private snackBar: MatSnackBar, private flightService: FlightService, private route: ActivatedRoute) { }

  ngOnInit(): void {

    this.route.params.subscribe(
      (params: Params) => {
        this.flightId = +params.flightId;
        if (params.passengerId) {
          this.flightService.getPassengerById(+params.passengerId).subscribe
            (data => {
              this.passenger = data[0];
              this.editMode = true;
              this.passengerId = +params.passengerId;
              this.initForm();
            });
        } else {
          this.editMode = false;
        }
      });

    this.flightService.getFlightById(this.flightId).subscribe(data => {
      this.flight = data[0];
    });

    this.flightService.getAllpassengers().subscribe(data => {
      this.passengerIdGen = (data.length) + 1;
    });



  }

  setStep(index: number): void {
    this.step = index;
  }

  nextStep(): void {
    this.step++;
  }

  prevStep(): void {
    this.step--;
  }


  initForm(): void {



    const array = this.passenger.passengerName.split(' ');

    this.passengerForm = new FormGroup({
      passengerFName: new FormControl(array[0]),
      passengerLName: new FormControl(array[1]),
      passengerPassportNum: new FormControl(this.passenger.passengerPassportNum),
      passengerAddress: new FormControl(this.passenger.passengerAddress),
      passengerDOB: new FormControl(new Date(this.passenger.passengerDOB)),
      passengerWithInfacts: new FormControl(this.passenger.
        passengerWithInfacts === true ? 'true' : 'false'),
      passengerWithWheelChair: new FormControl(this.passenger.
        passengerWithWheelChair === true ? 'true' : 'false'),
      passengerSpecialMealsTaken: new FormControl(this.passenger.
        passengerSpecialMealsTaken === true ? 'true' : 'false')

    });

  }

  formClick(): void {
    const passenger = new PassengerModel();
    if (this.editMode) {


      passenger.passengerId = this.passenger.passengerId;
      passenger.passengerName = this.passengerForm.value.passengerFName + ' ' + this.passengerForm.value.passengerLName;
      passenger.passengerAddress = this.passengerForm.value.passengerAddress;
      passenger.passengerDOB = this.passengerForm.value.passengerDOB;
      passenger.passengerPassportNum = this.passengerForm.value.passengerPassportNum;
      passenger.passengerWithInfacts = this.passengerForm.value.passengerWithInfacts === 'true' ? true : false;
      passenger.passengerWithWheelChair = this.passengerForm.value.passengerWithWheelChair === 'true' ? true : false;
      passenger.passengerSpecialMealsTaken = this.passengerForm.value.passengerSpecialMealsTaken === 'true' ? true : false;
      passenger.passengerAnicallaries = this.passenger.passengerAnicallaries;
      passenger.passengerMeals = this.passenger.passengerMeals;
      passenger.passengerShopping = this.passenger.passengerShopping;
      passenger.passengerSeatNumber = this.passenger.passengerSeatNumber;
      passenger.passengerFlightId = this.passenger.passengerFlightId;
      passenger.passengerCheckedIn = this.passenger.passengerCheckedIn;

      this.flightService.updatePassenger(passenger).subscribe(data => {
        console.log(data);

      });
      this.snackBar.open(' Passenger Successfully !!!', 'updated', {
        duration: 2000,
      });

      // window.location.reload();


    }
    else {


      passenger.passengerId = this.passengerIdGen;
      passenger.passengerName = this.passengerForm.value.passengerFName + ' ' + this.passengerForm.value.passengerLName;
      passenger.passengerAddress = this.passengerForm.value.passengerAddress;
      passenger.passengerDOB = this.passengerForm.value.passengerDOB;
      passenger.passengerPassportNum = this.passengerForm.value.passengerPassportNum;
      passenger.passengerWithInfacts = this.passengerForm.value.passengerWithInfacts === 'true' ? true : false;
      passenger.passengerWithWheelChair = this.passengerForm.value.passengerWithWheelChair === 'true' ? true : false;
      passenger.passengerSpecialMealsTaken = this.passengerForm.value.passengerSpecialMealsTaken === 'true' ? true : false;
      passenger.passengerAnicallaries = [];
      passenger.passengerMeals = [];
      passenger.passengerShopping = [];
      passenger.passengerSeatNumber = 0;
      passenger.passengerFlightId = this.flightId;
      this.flightService.addPassenger(passenger);
      this.snackBar.open(' Passenger Successfully !!!', 'Added', {
        duration: 2000,
      });

      window.location.reload();
    }
  }


}

