import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Params } from '@angular/router';
import { FlightService } from 'src/app/services/flight.service';
import { FlightModel } from 'src/app/models/flight-model';
import { PassengerModel } from 'src/app/models/passenger-model';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-ancillary-services-operations',
  templateUrl: './ancillary-services-operations.component.html',
  styleUrls: ['./ancillary-services-operations.component.sass']
})
export class AncillaryServicesOperationsComponent implements OnInit {

  constructor(private snackBar: MatSnackBar, private route: ActivatedRoute, private flightService: FlightService) { }

  id: number;
  operationValue: string;
  flight: FlightModel;
  addBox = false;
  deleteBox = false;
  updateBox = false;
  itemExist = false;
  Passengers: PassengerModel[];
  selectedAncillaryToUpdate: string = null;
  selectedAncillaryToDelete: string = null;

  addForm = new FormGroup({

    addInputItem: new FormControl('', {
      validators: [Validators.required]
    })
  });

  updateForm = new FormGroup({
    updateInputItem: new FormControl('', {
      validators: [Validators.required]
    })
  });

  ngOnInit(): void {

    this.route.params.subscribe(
      (params: Params) => {

        this.id = +params.flightId;

        if (params.ancillaries) {
          this.operationValue = params.ancillaries;
        }
        if (params.meals) {
          this.operationValue = params.meals;
        }
        if (params.shoppingItems) {
          this.operationValue = params.shoppingItems;
        }
        console.log(this.operationValue);
      }
    );



    this.flightService.getFlightById(this.id).subscribe(data => {
      this.flight = data[0]; console.log(this.flight);
    });

    this.flightService.getAllPassengersByFlightId(this.id).subscribe(data => {
      this.Passengers = data; console.log(this.Passengers);
    });

  }


  addOperation(): void {

    this.addBox = true;
    this.updateBox = false;
    this.deleteBox = false;
    this.updateForm.reset();
    this.selectedAncillaryToDelete = null;
    // this.selectedAncillaryToUpdate=null;
  }

  updateOperation(): void {

    this.updateBox = true;
    this.addBox = false;
    this.deleteBox = false;
    this.itemExist = false;
    this.addForm.reset();
    this.selectedAncillaryToDelete = null;
  }

  deleteOperation(): void {

    this.deleteBox = true;
    this.updateBox = false;
    this.addBox = false;
    this.itemExist = false;
    this.addForm.reset();
    this.updateForm.reset();
    this.selectedAncillaryToUpdate = null;
  }



  // add ancillary services in flight******************************************************************

  addServicesInFlight(): void {
    if (this.operationValue === 'ancillaries') {
      this.addAncillary();
    }
    if (this.operationValue === 'meals') {
      this.addMeals();
    }
    if (this.operationValue === 'shoppingItems') {
      this.addShoppingItems();
    }
  }

  // for ancillary added by admin*********************************************************************

  addAncillary(): void {

    let count = 0;
    for (const ancillary of this.flight.flightAncillaries) {
      if (this.addForm.value.addInputItem === ancillary) {
        count = 1;
        break;
      }
    }
    if (count === 0) {

      this.itemExist = false;
      this.flight.flightAncillaries.push(this.addForm.value.addInputItem);

      this.flightService.updateFlight(this.flight).subscribe(
        data => {
          this.addForm.reset();
        }
      );
      this.snackBar.open('Successfully !!!', 'Added', {
        duration: 2000,

      });
    } else {
      this.itemExist = true;
      this.addForm.reset();
    }

  }

  // for meals added by admin************************************************************************

  addMeals(): void {

    let count = 0;
    for (const meal of this.flight.flightMeals) {
      if (this.addForm.value.addInputItem === meal) {
        count = 1;
        break;
      }
    }
    if (count === 0) {

      this.itemExist = false;
      this.flight.flightMeals.push(this.addForm.value.addInputItem);

      this.flightService.updateFlight(this.flight).subscribe(
        data => {
          this.addForm.reset();
        }
      );
      this.snackBar.open('Successfully !!!', 'Added', {
        duration: 2000,

      });
    } else {
      this.itemExist = true;
      this.addForm.reset();
    }

  }

  // for shoppingItems added by admin******************************************************************

  addShoppingItems(): void {

    let count = 0;
    for (const shoppingItems of this.flight.flightShoppingItems) {
      if (this.addForm.value.addInputItem === shoppingItems) {
        count = 1;
        break;
      }
    }
    if (count === 0) {

      this.itemExist = false;
      this.flight.flightShoppingItems.push(this.addForm.value.addInputItem);

      this.flightService.updateFlight(this.flight).subscribe(
        data => {
          this.addForm.reset();
        }
      );
      this.snackBar.open('Successfully !!!', 'Added', {
        duration: 2000,

      });
    } else {
      this.itemExist = true;
      this.addForm.reset();
    }

  }


  // update ancillary services in flight ***************************************************************

  selectedItemUpdate(ancillary: string): void {

    this.selectedAncillaryToUpdate = ancillary;
    this.selectedAncillaryToDelete = null;
  }


  updateServicesInFlight(): void {

    if (this.operationValue === 'ancillaries') {
      this.updateAncillary();
    }
    if (this.operationValue === 'meals') {
      this.updateMeals();
    }
    if (this.operationValue === 'shoppingItems') {
      this.updateShoppingItems();
    }

  }

  updateAncillary(): void {

    let count = -1;
    this.flight.flightAncillaries.forEach(element => {
      count++;
      if (element === this.selectedAncillaryToUpdate) {
        this.flight.flightAncillaries[count] = this.updateForm.value.updateInputItem;
      }
    });

    for (const passenger of this.Passengers) {
      for (let i = 0; i < passenger.passengerAnicallaries.length; i++) {
        if (passenger.passengerAnicallaries[i] === this.selectedAncillaryToUpdate) {

          passenger.passengerAnicallaries[i] = this.updateForm.value.updateInputItem;
          this.flightService.updatePassenger(passenger).subscribe(data => {
            this.updateForm.reset();

          });
        }
      }
    }
    this.flightService.updateFlight(this.flight).subscribe(
      data => {
        this.updateForm.reset();
      }
    );
    this.snackBar.open('Successfully !!!', 'updated', {
      duration: 2000,

    });


  }

  updateMeals(): void {

    let count = -1;
    this.flight.flightMeals.forEach(element => {
      count++;
      if (element === this.selectedAncillaryToUpdate) {
        this.flight.flightAncillaries[count] = this.updateForm.value.updateInputItem;
      }
    });

    for (const passenger of this.Passengers) {
      for (let i = 0; i < passenger.passengerMeals.length; i++) {
        if (passenger.passengerMeals[i] === this.selectedAncillaryToUpdate) {

          passenger.passengerMeals[i] = this.updateForm.value.updateInputItem;
          this.flightService.updatePassenger(passenger).subscribe(data => {
            this.updateForm.reset();

          });
        }
      }
    }
    this.flightService.updateFlight(this.flight).subscribe(
      data => {
        this.updateForm.reset();
      }
    );
    this.snackBar.open('Successfully !!!', 'updated', {
      duration: 2000,

    });


  }

  updateShoppingItems(): void {

    let count = -1;
    this.flight.flightShoppingItems.forEach(element => {
      count++;
      if (element === this.selectedAncillaryToUpdate) {
        this.flight.flightShoppingItems[count] = this.updateForm.value.updateInputItem;
      }
    });

    for (const passenger of this.Passengers) {
      for (let i = 0; i < passenger.passengerShopping.length; i++) {
        if (passenger.passengerShopping[i] === this.selectedAncillaryToUpdate) {

          passenger.passengerAnicallaries[i] = this.updateForm.value.updateInputItem;
          this.flightService.updatePassenger(passenger).subscribe(data => {
            this.updateForm.reset();

          });
        }
      }
    }
    this.flightService.updateFlight(this.flight).subscribe(
      data => {
        this.updateForm.reset();
      }
    );
    this.snackBar.open('Successfully !!!', 'updated', {
      duration: 2000,

    });



  }



  // delete ancillary services from flight ************************************************************

  selectedItemDelete(ancillary: string): void {

    this.selectedAncillaryToDelete = ancillary;
    this.selectedAncillaryToUpdate = null;
  }

  deleteServicesInFlight(): void {

    if (this.operationValue === 'ancillaries') {
      this.deleteAncillary();
    }
    if (this.operationValue === 'meals') {
      this.deleteMeals();
    }
    if (this.operationValue === 'shoppingItems') {
      this.deleteShoppingItems();
    }

  }


  deleteAncillary(): void {
    let count = -1;
    this.flight.flightAncillaries.forEach(element => {
      count++;
      if (element === this.selectedAncillaryToDelete) {
        this.flight.flightAncillaries.splice(count, 1);
      }
    });

    for (const passenger of this.Passengers) {
      for (let i = 0; i < passenger.passengerAnicallaries.length; i++) {
        if (passenger.passengerAnicallaries[i] === this.selectedAncillaryToDelete) {

          passenger.passengerAnicallaries.splice(i, 1);
          this.flightService.updatePassenger(passenger).subscribe(data => {
            console.log(data);

          });
        }
      }
    }
    this.flightService.updateFlight(this.flight).subscribe(
      data => {
        console.log(data);
      }
    );
    this.snackBar.open('Successfully !!!', 'deleted', {
      duration: 2000,

    });

  }

  deleteMeals(): void {

    let count = -1;
    this.flight.flightMeals.forEach(element => {
      count++;
      if (element === this.selectedAncillaryToDelete) {
        this.flight.flightMeals.splice(count, 1);
      }
    });

    for (const passenger of this.Passengers) {
      for (let i = 0; i < passenger.passengerMeals.length; i++) {
        if (passenger.passengerMeals[i] === this.selectedAncillaryToDelete) {

          passenger.passengerMeals.splice(i, 1);
          this.flightService.updatePassenger(passenger).subscribe(data => {
            console.log(data);

          });
        }
      }
    }
    this.flightService.updateFlight(this.flight).subscribe(
      data => {
        console.log(data);
      }
    );
    this.snackBar.open('Successfully !!!', 'deleted', {
      duration: 2000,

    });


  }

  deleteShoppingItems(): void {

    let count = -1;
    this.flight.flightShoppingItems.forEach(element => {
      count++;
      if (element === this.selectedAncillaryToDelete) {
        this.flight.flightShoppingItems.splice(count, 1);
      }
    });

    for (const passenger of this.Passengers) {
      for (let i = 0; i < passenger.passengerShopping.length; i++) {
        if (passenger.passengerShopping[i] === this.selectedAncillaryToDelete) {

          passenger.passengerShopping.splice(i, 1);
          this.flightService.updatePassenger(passenger).subscribe(data => {
            console.log(data);

          });
        }
      }
    }
    this.flightService.updateFlight(this.flight).subscribe(
      data => {
        console.log(data);
      }
    );
    this.snackBar.open('Successfully !!!', 'deleted', {
      duration: 2000,

    });


  }

}

