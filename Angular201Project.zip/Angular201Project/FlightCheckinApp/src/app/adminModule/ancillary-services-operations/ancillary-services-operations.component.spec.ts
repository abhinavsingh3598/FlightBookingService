import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AncillaryServicesOperationsComponent } from './ancillary-services-operations.component';

describe('AncillaryServicesOperationsComponent', () => {
  let component: AncillaryServicesOperationsComponent;
  let fixture: ComponentFixture<AncillaryServicesOperationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AncillaryServicesOperationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AncillaryServicesOperationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
