import { Component, OnInit, Inject } from '@angular/core';
import { AdminModel } from 'src/app/models/admin-model';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FlightService } from 'src/app/services/flight.service';
import { Router, ActivatedRoute } from '@angular/router';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-admin-dailog',
  templateUrl: './admin-dailog.component.html',
  styleUrls: ['./admin-dailog.component.sass']
})
export class AdminDailogComponent implements OnInit {

  // to identify between the forms for signup and login of admin
  whichForm = this.data;
  adminModel: AdminModel;
  admins: AdminModel[];
  validLogin = false;

  hide = true;

  signupform = new FormGroup({

    adminEmail: new FormControl('', {
      validators: [Validators.required]
    }),

    adminUserName: new FormControl('', {
      validators: [Validators.required]
    }),

    adminPassword: new FormControl('', {
      validators: [Validators.required]
    })
  });

  loginForm = new FormGroup({

    adminUserName: new FormControl('', {
      validators: [Validators.required]
    }),

    adminPassword: new FormControl('', {
      validators: [Validators.required]
    })
  });


  constructor(private snackBar: MatSnackBar, private flightService: FlightService, private dialogRef: MatDialogRef<AdminDailogComponent>
    ,         @Inject(MAT_DIALOG_DATA) public data: any, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.flightService.getAllAdmins().subscribe(data => { this.admins = data; console.log(this.admins); });
  }

  onSignUpSubmit(message: string, action: string): void {

    this.adminModel = new AdminModel();
    this.adminModel.adminEmail = this.signupform.value.adminEmail;
    this.adminModel.adminUserName = this.signupform.value.adminUserName;
    this.adminModel.adminPassword = this.signupform.value.adminPassword;
    console.log(this.adminModel);
    this.flightService.addAdmin(this.adminModel);
    this.snackBar.open(message, action, {
      duration: 2000,

    });


  }

  onLoginSubmit(): void {

    // tslint:disable-next-line: prefer-for-of
    for (let i = 0; i < this.admins.length; i++) {
      if (this.loginForm.value.adminUserName === this.admins[i].adminUserName &&
        this.loginForm.value.adminPassword === this.admins[i].adminPassword) {
        this.validLogin = true;
        const admin = new AdminModel();
        admin.adminUserName = this.admins[i].adminUserName;
        admin.adminPassword = this.admins[i].adminPassword;
        this.flightService.setadminObjectForLocalStorage(admin);

        break;
      }
    }
    if (this.validLogin) {
      localStorage.setItem('admin', JSON.stringify(this.flightService.getadminObjectForLocalStorage()));
      this.router.navigate(['/admin_dashboard'], { relativeTo: this.route });
    }
    else {

      alert('Wrong Credentionals!!!!  or Signup if you are new User');

      window.location.reload();

    }

  }

  onNoClick(): void {

    this.dialogRef.close();
    this.flightService.onDailogCancel();
    window.location.reload();
  }




}
