import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/Forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { AppMaterial } from '../app.material';
import { AddPassengersInFlightsComponent } from './add-passengers-in-flights/add-passengers-in-flights.component';
import { AdminDailogComponent } from './admin-dailog/admin-dailog.component';
import { AdminRoutingModule } from './admin-routing.module';
import { AncillaryServicesOperationsComponent } from './ancillary-services-operations/ancillary-services-operations.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ManageAncillaryServicesComponent } from './manage-ancillary-services/manage-ancillary-services.component';
import { ManagePassengersComponent } from './manage-passengers/manage-passengers.component';
import { PassengerFormComponent } from './passenger-form/passenger-form.component';
@NgModule({
    declarations: [
        AddPassengersInFlightsComponent,
        AdminDailogComponent,
        AncillaryServicesOperationsComponent,
        DashboardComponent,
        ManageAncillaryServicesComponent,
        ManagePassengersComponent,
        PassengerFormComponent
    ],
    imports: [
        RouterModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        AppMaterial,
        AdminRoutingModule

    ],
    exports: [
    ],
    providers: [],
})

export class AdminModule { }
