import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageAncillaryServicesComponent } from './manage-ancillary-services.component';

describe('ManageAncillaryServicesComponent', () => {
  let component: ManageAncillaryServicesComponent;
  let fixture: ComponentFixture<ManageAncillaryServicesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageAncillaryServicesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageAncillaryServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
