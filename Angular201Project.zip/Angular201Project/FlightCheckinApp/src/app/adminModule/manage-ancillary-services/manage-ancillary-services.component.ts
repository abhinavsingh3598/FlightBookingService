import { Component, OnInit, ViewChild } from '@angular/core';
import { MatSort } from '@angular/material/sort';
import { FlightModel } from 'src/app/models/flight-model';
import { FlightService } from 'src/app/services/flight.service';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-manage-ancillary-services',
  templateUrl: './manage-ancillary-services.component.html',
  styleUrls: ['./manage-ancillary-services.component.sass']
})
export class ManageAncillaryServicesComponent implements OnInit {

  constructor(private flightService: FlightService) { }

  displayedColumns: string[] = ['flightId', 'flightName', 'flightArrivalCity', 'flightDestinationCity', 'flightTotalTimeDuration',
    'flightCost', 'flightAncillaries', 'flightMeals', 'flightShoppingItems'];

  flights: FlightModel[];
  datasource: any;
  @ViewChild(MatSort, { static: false }) sort: MatSort;


  ngOnInit(): void {
    this.flightService.getAllFlights().subscribe(data => {
      this.flights = data;
      this.datasource = new MatTableDataSource(this.flights);
      this.datasource.sort = this.sort;
    });

  }



}

