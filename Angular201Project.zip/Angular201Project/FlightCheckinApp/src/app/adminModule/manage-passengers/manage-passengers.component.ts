import { Component, OnInit, ViewChild } from '@angular/core';
import { FlightService } from 'src/app/services/flight.service';
import { FlightModel } from 'src/app/models/flight-model';
import { PassengerModel } from 'src/app/models/passenger-model';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';

@Component({
  selector: 'app-manage-passengers',
  templateUrl: './manage-passengers.component.html',
  styleUrls: ['./manage-passengers.component.sass']
})
export class ManagePassengersComponent implements OnInit {

  constructor(private flightService: FlightService) { }

  flights: FlightModel[];
  passengers: PassengerModel[];

  filter = { passport: false, address: false, dob: false };
  filteredPassengers: PassengerModel[] = [];
  datasource: any
  @ViewChild(MatSort, { static: false }) sort: MatSort;

  displayedColumns: string[] = ['flightId', 'passengerId', 'passengerName', 'passengerSeatNumber', 'passengerUpdate'
  ];

  ngOnInit(): void {

    this.flightService.getAllpassengers().subscribe(data => {
      this.passengers = data;
      this.filteredPassengers = this.passengers;

      this.datasource = new MatTableDataSource(this.filteredPassengers);
      console.log(this.datasource);

      this.datasource.sort = this.sort;
      console.log(this.datasource);
    });

  }

  filterChange(): void {

    if (this.filter.passport === false && this.filter.address === false && this.filter.dob === false) {

      this.filteredPassengers = this.passengers;
    } else {

      // Only passport missing
      if (this.filter.passport === true && this.filter.address === false && this.filter.dob === false) {
        this.filteredPassengers = this.passengers.filter(x =>
          x.passengerPassportNum.length === 0);
      }
      // Only address missing
      if (this.filter.passport === false && this.filter.address === true && this.filter.dob === false) {
        this.filteredPassengers = this.passengers.filter(x =>
          x.passengerAddress.length === 0);
      }

      // Only Date of Birth missing
      if (this.filter.passport === false && this.filter.address === false && this.filter.dob === true) {
        this.filteredPassengers = this.passengers.filter(x =>
          x.passengerDOB.length === 0);
      }

      // Only passport and addtress missing
      if (this.filter.passport === true && this.filter.address === true && this.filter.dob === false) {
        this.filteredPassengers = this.passengers.filter(x =>
          (x.passengerPassportNum.length === 0) && (x.passengerAddress.length === 0));
      }

      // Only passport and Date Of Birth missing
      if (this.filter.passport === true && this.filter.address === false && this.filter.dob === true) {
        this.filteredPassengers = this.passengers.filter(x =>
          (x.passengerPassportNum.length === 0) && (x.passengerDOB.length === 0));
      }
      // Only adress and Date Of Birth missing
      if (this.filter.passport === false && this.filter.address === true && this.filter.dob === true) {
        this.filteredPassengers = this.passengers.filter(x =>
          (x.passengerAddress.length === 0) && (x.passengerDOB.length === 0));
      }

      // Only  passport adress and Date Of Birth missing
      if (this.filter.passport === true && this.filter.address === true && this.filter.dob === true) {
        this.filteredPassengers = this.passengers.filter(x =>
          (x.passengerPassportNum.length === 0) && (x.passengerAddress.length === 0
          ) && (x.passengerDOB.length === 0));
      }

    }
    this.datasource = new MatTableDataSource(this.filteredPassengers);
    console.log(this.datasource);

    this.datasource.sort = this.sort;
    console.log(this.datasource);

  }



}

