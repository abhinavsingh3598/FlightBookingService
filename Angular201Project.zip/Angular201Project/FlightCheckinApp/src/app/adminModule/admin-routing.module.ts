import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from '../auth.guard';
import { AddPassengersInFlightsComponent } from './add-passengers-in-flights/add-passengers-in-flights.component';
import { AdminDailogComponent } from './admin-dailog/admin-dailog.component';
import { AncillaryServicesOperationsComponent } from './ancillary-services-operations/ancillary-services-operations.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ManageAncillaryServicesComponent } from './manage-ancillary-services/manage-ancillary-services.component';
import { ManagePassengersComponent } from './manage-passengers/manage-passengers.component';
import { PassengerFormComponent } from './passenger-form/passenger-form.component';

const routes: Routes = [
  // {
  //   path: '', redirectTo: 'admin_dashboard', pathMatch: 'full'
  // },
  {
    path: 'admin_dashboard', component: DashboardComponent, canActivate: [AuthGuard], data: { role: 'admin' }
  },
  {
    path: 'adminlogin', component: AdminDailogComponent, canActivate: [AuthGuard], data: { role: 'admin' }
  },
  {
    path: 'adminsignup', component: AdminDailogComponent, canActivate: [AuthGuard], data: { role: 'admin' }
  },
  {
    path: 'ManageAncillaryServices', component: ManageAncillaryServicesComponent, canActivate: [AuthGuard], data: { role: 'admin' }
  },
  {
    path: 'ManagePassengers', component: ManagePassengersComponent, canActivate: [AuthGuard], data: { role: 'admin' }
  },
  {
    path: 'manageAncillaries/:flightId/:ancillaries', component: AncillaryServicesOperationsComponent,
    canActivate: [AuthGuard], data: { role: 'admin' }
  },
  {
    path: 'manageMeals/:flightId/:meals', component: AncillaryServicesOperationsComponent, canActivate: [AuthGuard], data: { role: 'admin' }
  },
  {
    path: 'manageShoppingItems/:flightId/:shoppingItems', component: AncillaryServicesOperationsComponent,
    canActivate: [AuthGuard], data: { role: 'admin' }
  },
  {
    path: 'addPassengers', component: AddPassengersInFlightsComponent, canActivate: [AuthGuard], data: { role: 'admin' }
  },
  {
    path: 'managePassengers', component: ManagePassengersComponent, canActivate: [AuthGuard], data: { role: 'admin' }
  },
  {
    path: 'addPassengerInSelectedFlight/:flightId', component: PassengerFormComponent, canActivate: [AuthGuard], data: { role: 'admin' }
  },
  {
    path: 'updatePassengerInSelectedFlight/:passengerId', component: PassengerFormComponent,
    canActivate: [AuthGuard], data: { role: 'admin' }
  },

];
@NgModule({
  declarations: [],
  imports: [CommonModule, RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [],
})

export class AdminRoutingModule {

}
